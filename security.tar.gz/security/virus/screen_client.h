#include <iostream>
#include <string>
#pragma comment(lib, "ws2_32.lib") // for socket programming
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

// include image processing libraries
#define cimg_use_png
#include <CImg.h>
using namespace cimg_library;

int main()
{
    // Initialize Winsock
    WSADATA wsData;
    WORD ver = MAKEWORD(2, 2);

    int wsOK = WSAStartup(ver, &wsData);
    if (wsOK != 0) {
        std::cerr << "Can't Initialize winsock! Quitting" << std::endl;
        return -1;
    }

    // Create a socket object
    SOCKET client_socket = socket(AF_INET, SOCK_STREAM, 0);

    // Define the server's host and port
    std::string server_host = "192.168.43.97"; // Replace with the remote host's IP address
    int server_port = 9999;

    // Create a hint structure for the server
    sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(server_port);
    inet_pton(AF_INET, server_host.c_str(), &server_addr.sin_addr);

    // Connect to the server
    int connResult = connect(client_socket, (sockaddr*)&server_addr, sizeof(server_addr));
    if (connResult == SOCKET_ERROR) {
        std::cerr << "Can't connect to the server! Quitting" << std::endl;
        closesocket(client_socket);
        WSACleanup();
        return -1;
    }

    // Receive the screenshot size from the server
    int screenshot_size;
    char buffer[1024];
    memset(buffer, 0, 1024);
    int bytesReceived = recv(client_socket, buffer, 1024, 0);
    if (bytesReceived == SOCKET_ERROR) {
        std::cerr << "Error in receiving screenshot size from server! Quitting" << std::endl;
        closesocket(client_socket);
        WSACleanup();
        return -1;
    }
    screenshot_size = atoi(buffer);

    // Receive the screenshot data from the server
    std::vector<char> screenshot_data(screenshot_size);
    int totalBytesReceived = 0;
    int remainingBytes = screenshot_size;
    while (remainingBytes > 0) {
        bytesReceived = recv(client_socket, &screenshot_data[totalBytesReceived], remainingBytes, 0);
        if (bytesReceived == SOCKET_ERROR) {
            std::cerr << "Error in receiving screenshot data from server! Quitting" << std::endl;
            closesocket(client_socket);
            WSACleanup();
            return -1;
        }
        totalBytesReceived += bytesReceived;
        remainingBytes -= bytesReceived;
    }

    // Create an image object from the received data
    CImg<unsigned char> image;
    unsigned char* data = reinterpret_cast<unsigned char*>(screenshot_data.data());
    cimg_library::CImgList<unsigned char> list(data, data + screenshot_size, 1, 1, 1, 3);
    image.assign(list[0].width(), list[0].height(), 1, 3);
    memcpy(image.data(), list[0].data(), list[0].size());

    // Display the received screenshot
    image.display("Screenshot");

    // Close the connection
    closesocket(client_socket);
    WSACleanup();

    return 0;
}
