#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main() {
    int server_socket, client_socket;
    sockaddr_in server_address, client_address;
    char buffer[4096];

    server_socket = socket(AF_INET, SOCK_STREAM, 0);

    memset(&server_address, '0', sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(9999);

    bind(server_socket, (sockaddr*)&server_address, sizeof(server_address));

    listen(server_socket, 1);
    cout << "Server listening on " << inet_ntoa(server_address.sin_addr) << ":" << ntohs(server_address.sin_port) << endl;

    while (true) {
        socklen_t client_address_size = sizeof(client_address);
        client_socket = accept(server_socket, (sockaddr*)&client_address, &client_address_size);
        cout << "Connection established from " << inet_ntoa(client_address.sin_addr) << ":" << ntohs(client_address.sin_port) << endl;

        // Take a screenshot
        Rect screen_rect(Point(0, 0), Point(1920, 1080));
        Mat screenshot;
        VideoCapture capture("/dev/video0");
        capture.set(CV_CAP_PROP_FRAME_WIDTH, 1920);
        capture.set(CV_CAP_PROP_FRAME_HEIGHT, 1080);
        capture.grab();
        capture.retrieve(screenshot);
        imwrite("screenshot.png", screenshot);

        // Open the screenshot image and convert it to bytes
        FILE* file_pointer = fopen("screenshot.png", "rb");
        fseek(file_pointer, 0, SEEK_END);
        int screenshot_size = ftell(file_pointer);
        rewind(file_pointer);
        char* screenshot_data = new char[screenshot_size];
        fread(screenshot_data, sizeof(char), screenshot_size, file_pointer);
        fclose(file_pointer);

        // Send the screenshot size to the client
        memset(buffer, 0, sizeof(buffer));
        snprintf(buffer, sizeof(buffer), "%d", screenshot_size);
        send(client_socket, buffer, strlen(buffer), 0);

        // Send the screenshot data to the client
        int bytes_sent = 0;
        while (bytes_sent < screenshot_size) {
            int bytes_to_send = min(4096, screenshot_size - bytes_sent);
            bytes_sent += send(client_socket, screenshot_data + bytes_sent, bytes_to_send, 0);
        }

        // Close the connection
        close(client_socket);
        cout << "Screenshot sent to " << inet_ntoa(client_address.sin_addr) << ":" << ntohs(client_address.sin_port) << endl;
    }
    
    return 0;
}
